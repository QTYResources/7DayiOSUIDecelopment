//
//  ViewController.m
//  UIPageControlTest
//
//  Created by apple on 16/1/27.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor redColor];
    UIPageControl * pageControl = [[UIPageControl alloc]initWithFrame:CGRectMake(20, 100, 280, 30)];
    pageControl.numberOfPages = 10;
    pageControl.currentPage=5;
    pageControl.pageIndicatorTintColor = [UIColor blackColor];
    pageControl.currentPageIndicatorTintColor = [UIColor greenColor];
    [pageControl addTarget:self action:@selector(pageChange:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:pageControl];
}

-(void)pageChange:(UIPageControl *)page{
    NSLog(@"%lu",page.currentPage);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
