//
//  ViewController.m
//  UISwitchTest
//
//  Created by apple on 16/1/25.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UISwitch * swi = [[UISwitch alloc]init];
    swi.center = CGPointMake(100, 100);
    [self.view addSubview:swi];
    
    swi.onTintColor = [UIColor greenColor];
    swi.tintColor = [UIColor redColor];
    swi.thumbTintColor = [UIColor orangeColor];
    
    [swi addTarget:self action:@selector(change:) forControlEvents:UIControlEventValueChanged];
    
    
}
-(void)change:(UISwitch *)swi{
    NSLog(@"%d",swi.on);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
