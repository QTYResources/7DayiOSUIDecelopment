//
//  ViewController.m
//  UIStepperTest
//
//  Created by apple on 16/1/27.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIStepper * stepper = [[UIStepper alloc]init];
    stepper.center=CGPointMake(100, 100);
    stepper.continuous = YES;
    stepper.autorepeat = YES;
    stepper.wraps=YES;
    stepper.minimumValue =0;
    stepper.maximumValue =10;
    stepper.stepValue = 1;
    stepper.tintColor = [UIColor blueColor];
    [stepper addTarget:self action:@selector(valueChange:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:stepper];
    
    
//    [stepper setBackgroundImage:[UIImage imageNamed:@"image"] forState:UIControlStateNormal];
//    [stepper setDividerImage:[UIImage imageNamed:@"image"] forLeftSegmentState:UIControlStateNormal rightSegmentState:UIControlStateNormal];
//    [stepper setIncrementImage:[[UIImage imageNamed:@"image"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
//    [stepper setDecrementImage:[[UIImage imageNamed:@"image"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
}
-(void)valueChange:(UIStepper *)step{
    NSLog(@"%f",step.value);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
