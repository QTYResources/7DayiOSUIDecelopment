//
//  ViewController.m
//  UIAlertViewTest
//
//  Created by apple on 16/1/27.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIAlertViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"警告标题" message:@"警告内容" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定",@"more", nil];
    alert.alertViewStyle = UIAlertViewStyleDefault;
    [alert show];
}
//点击按钮后系统调用的方法
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
}
//警告框将要消失时调用的方法
-(void)alertView:(UIAlertView *)alertView willDismissWithButtonIndex:(NSInteger)buttonIndex{
    
}
//警告框已经消失时调用的方法
-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
