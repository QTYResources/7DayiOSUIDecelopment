//
//  ViewController.m
//  UIDatePickerTest
//
//  Created by apple on 16/1/25.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIDatePicker * datePicker = [[UIDatePicker alloc]initWithFrame:CGRectMake(20, 100, 280, 150)];
    datePicker.datePickerMode = UIDatePickerModeTime;
    [datePicker addTarget:self action:@selector(change:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:datePicker];
}
-(void)change:(UIDatePicker *)picker{
    NSLog(@"%@",picker.date);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
