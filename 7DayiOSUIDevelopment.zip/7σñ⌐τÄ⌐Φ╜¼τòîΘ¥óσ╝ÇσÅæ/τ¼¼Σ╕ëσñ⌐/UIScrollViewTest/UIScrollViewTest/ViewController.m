//
//  ViewController.m
//  UIScrollViewTest
//
//  Created by apple on 16/2/6.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIScrollViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIScrollView * scrollView = [[UIScrollView alloc]initWithFrame:self.view.frame];
    UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width*3, self.view.frame.size.height*1.5)];
    imageView.image = [UIImage imageNamed:@"image"];
    [scrollView addSubview:imageView];
    scrollView.contentSize = imageView.frame.size;
    [self.view addSubview:scrollView];
    scrollView.delegate=self;
    
    scrollView.contentOffset = CGPointMake(100, 100);
    scrollView.directionalLockEnabled = YES;
    scrollView.bounces=NO;
    scrollView.alwaysBounceHorizontal=NO;
    scrollView.alwaysBounceVertical=NO;
    scrollView.pagingEnabled=YES;
    scrollView.showsHorizontalScrollIndicator=YES;
    scrollView.showsVerticalScrollIndicator=NO;
    scrollView.indicatorStyle = UIScrollViewIndicatorStyleDefault;
    
    scrollView.minimumZoomScale=0.3;
    scrollView.maximumZoomScale=2.0;
    scrollView.bouncesZoom=YES;
}

//滚动视图减速结束时调用的代理方法
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
}
//用户停止拖拽时调用的代理方法
-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    
}
//滚动视图将要结束滚动动画时调用的方法
-(void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView{
    
}
//滚动视图缩放结束后调用的方法
-(void)scrollViewDidEndZooming:(UIScrollView *)scrollView withView:(UIView *)view atScale:(CGFloat)scale{
    
}
//滚动视图开始滚动时调用的方法
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
}
//滚动视图滚动到顶端时调用的方法
-(void)scrollViewDidScrollToTop:(UIScrollView *)scrollView{
    
}
//滚动视图进行缩放时调用的方法
-(void)scrollViewDidZoom:(UIScrollView *)scrollView{
    
}
//滚动视图将要滚动到顶端时调用的方法
-(BOOL)scrollViewShouldScrollToTop:(UIScrollView *)scrollView{
    return YES;
}
//滚动视图将要开始减速时调用的方法
-(void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView{
    
}
//滚动视图将要开始被拖拽时调用的方法
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    
}
//滚动视图将要开始缩放时触发的方法
-(void)scrollViewWillBeginZooming:(UIScrollView *)scrollView withView:(UIView *)view{
    
}
//滚动视图将要结束拖拽时调用的方法
-(void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset{
    
}

-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    return scrollView.subviews.firstObject;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
