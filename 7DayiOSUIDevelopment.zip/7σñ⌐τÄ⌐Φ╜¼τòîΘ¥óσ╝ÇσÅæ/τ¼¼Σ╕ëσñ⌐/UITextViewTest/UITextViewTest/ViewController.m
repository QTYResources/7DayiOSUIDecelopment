//
//  ViewController.m
//  UITextViewTest
//
//  Created by apple on 16/2/14.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITextViewDelegate>
{
    UITextView * textView;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    textView = [[UITextView alloc]initWithFrame:CGRectMake(20, 100, 280, 200)];
    textView.backgroundColor = [UIColor grayColor];
    textView.font = [UIFont italicSystemFontOfSize:20];
    textView.textColor = [UIColor whiteColor];
//    textView.dataDetectorTypes = UIDataDetectorTypeAll;
//    textView.editable=NO;
    textView.delegate = self;
    textView.text = @"phoneNum:\n13212412351";
    textView.textAlignment = NSTextAlignmentCenter;
    textView.selectable=YES;
    [self.view addSubview:textView];
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [textView resignFirstResponder];
}
//textView中字符将要改变时触发的方法
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    return YES;
}
//textView已经开始编辑时触发的方法
-(void)textViewDidBeginEditing:(UITextView *)textView{
    
}
//textView将要开始编辑时触发的方法
-(BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    return YES;
}
//textView中选中的文字改变时触发的方法
-(void)textViewDidChangeSelection:(UITextView *)textView{
    NSRange range = textView.selectedRange;
}
//textView字符改变后触发的方法
-(void)textViewDidChange:(UITextView *)textView{
    
}
//textView结束编辑时触发的方法
-(void)textViewDidEndEditing:(UITextView *)textView{
    
}
//textView将要结束编辑时触发的方法
-(BOOL)textViewShouldEndEditing:(UITextView *)textView{
    return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
