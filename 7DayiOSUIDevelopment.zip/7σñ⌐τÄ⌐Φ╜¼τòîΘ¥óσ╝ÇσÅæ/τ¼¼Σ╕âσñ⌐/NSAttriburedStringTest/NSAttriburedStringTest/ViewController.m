//
//  ViewController.m
//  NSAttriburedStringTest
//
//  Created by apple on 16/3/24.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    //字符串属性字典
//    NSMutableDictionary * attriDic = [[NSMutableDictionary alloc]init];
//    //设置字体
//    [attriDic setObject:[UIFont italicSystemFontOfSize:20] forKey:NSFontAttributeName];
//    //设置文字颜色
//    [attriDic setObject:[UIColor redColor] forKey:NSForegroundColorAttributeName];
//    //设置背景颜色
//    [attriDic setObject:[UIColor greenColor] forKey:NSBackgroundColorAttributeName];
//    //设置下划线风格
//    [attriDic setObject:@(NSUnderlineStyleDouble) forKey:NSUnderlineStyleAttributeName];
//    NSAttributedString * attriStr  = [[NSAttributedString alloc]initWithString:@"My name is 珲少,welcome to iOS world!" attributes:attriDic];
    NSMutableAttributedString * mutableStr = [[NSMutableAttributedString alloc]initWithString:@"My name is 珲少,welcome to iOS world!"];
    //添加属性
    [mutableStr addAttribute:NSFontAttributeName value:[UIFont italicSystemFontOfSize:40] range:NSMakeRange(0, 5)];
    [mutableStr addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(6, 10)];
    [mutableStr addAttribute:NSUnderlineStyleAttributeName value:@(NSUnderlineStyleThick) range:NSMakeRange(11, 10)];
    UILabel * label = [[UILabel alloc]init];
    label.frame = CGRectMake(20, 100, 300, 80);
    label.numberOfLines= 0;
    label.attributedText = mutableStr;
    [self.view addSubview:label];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
