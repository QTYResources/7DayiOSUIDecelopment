//
//  ModelViewController.h
//  UIPageViewControllreTest
//
//  Created by apple on 16/3/23.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModelViewController : UIViewController
//创建自身类对象的类方法
+(ModelViewController *)creatWithIndex:(int)index;
@property(nonatomic,strong)UILabel * indexLabel;
@end
