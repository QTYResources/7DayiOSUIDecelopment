//
//  ViewController.m
//  MapKitTestTwo
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"
#import <MapKit/MapKit.h>
@interface ViewController ()<MKMapViewDelegate>
{
    MKMapView * mapView;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    mapView =[[MKMapView alloc]initWithFrame:self.view.frame];
    mapView.region=MKCoordinateRegionMake(CLLocationCoordinate2DMake(33.33, 113.33), MKCoordinateSpanMake(0.01, 0.01));
    mapView.mapType=MKMapTypeStandard;
    mapView.delegate=self;
    [self.view addSubview:mapView];
    
//    //导航设置
//    CLLocationCoordinate2D fromcoor=CLLocationCoordinate2DMake(39.26, 116.3);
    CLLocationCoordinate2D tocoor = CLLocationCoordinate2DMake(33.33, 113.33);
//    //创建出发点和目的点信息
//    MKPlacemark *fromPlace = [[MKPlacemark alloc] initWithCoordinate:fromcoor
//                                                   addressDictionary:nil];
//    MKPlacemark *toPlace = [[MKPlacemark alloc]initWithCoordinate:tocoor addressDictionary:nil];
//    //创建出发节点和目的地节点
//    MKMapItem * fromItem = [[MKMapItem alloc]initWithPlacemark:fromPlace];
//    MKMapItem * toItem = [[MKMapItem alloc]initWithPlacemark:toPlace];
//    //初始化导航搜索请求
//    MKDirectionsRequest *request = [[MKDirectionsRequest alloc]init];
//    request.source=fromItem;
//    request.destination=toItem;
//    request.requestsAlternateRoutes=YES;
//    //初始化请求检索
//    MKDirections *directions = [[MKDirections alloc]initWithRequest:request];
//    //开始检索，结果会返回在block中
//    [directions calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
//        if (error) {
//            NSLog(@"error:%@",error);
//        }else{
//            //提取导航线路结果中的一条线路
//            MKRoute *route =response.routes[0];
//            //将线路中的每一步详情提取出来
//            NSArray * stepArray = [NSArray arrayWithArray:route.steps];
//            //进行遍历
//            for (int i=0; i<stepArray.count; i++) {
//                //线路的详情节点
//                MKRouteStep * step = stepArray[i];
//                //在此节点处添加一个大头针
//                MKPointAnnotation * point = [[MKPointAnnotation alloc]init];
//                point.coordinate=step.polyline.coordinate;
//                point.title=step.instructions;
//                point.subtitle=step.notice;
//                [mapView addAnnotation:point];
//                //将此段线路添加到地图上
//                [mapView addOverlay:step.polyline];
//            }
//        }
//    }];
//    CLLocationCoordinate2D tocoor = CLLocationCoordinate2DMake(33.33, 113.33);
    //创建一个位置信息对象，第一个参数为经纬度，第二个为纬度检索范围，单位为米，第三个为经度检索范围，单位为米
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(tocoor, 5000, 5000);
    //初始化一个检索请求对象
    MKLocalSearchRequest * req = [[MKLocalSearchRequest alloc]init];
    //设置检索参数
    req.region=region;
    //兴趣点关键字
    req.naturalLanguageQuery=@"school";
    //初始化检索
    MKLocalSearch * ser = [[MKLocalSearch alloc]initWithRequest:req];
    //开始检索，结果返回在block中
    [ser startWithCompletionHandler:^(MKLocalSearchResponse *response, NSError *error) {
        //兴趣点节点数组
        NSArray * array = [NSArray arrayWithArray:response.mapItems];
        for (int i=0; i<array.count; i++) {
            MKMapItem * item=array[i];
            MKPointAnnotation * point = [[MKPointAnnotation alloc]init];
            point.title=item.name;
            point.subtitle=item.phoneNumber;
            point.coordinate=item.placemark.coordinate;
            [mapView addAnnotation:point];
        }
    }];
}
//地图覆盖物的代理方法
-(MKOverlayRenderer *)mapView:(MKMapView *)mapView rendererForOverlay:(id<MKOverlay>)overlay{
    MKPolylineRenderer *renderer = [[MKPolylineRenderer alloc] initWithPolyline:overlay];
    
    renderer.strokeColor = [UIColor redColor];
    
    renderer.lineWidth = 4.0;
    
    return  renderer;
}
//标注的代理方法
-(MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation{
    MKPinAnnotationView * view= [[MKPinAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:@"anno"];
    view.canShowCallout=YES;
    return view;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
