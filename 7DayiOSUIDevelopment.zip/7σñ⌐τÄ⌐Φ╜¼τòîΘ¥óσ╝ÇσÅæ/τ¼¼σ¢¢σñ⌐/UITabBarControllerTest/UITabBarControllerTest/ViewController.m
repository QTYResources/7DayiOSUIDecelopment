//
//  ViewController.m
//  UITabBarControllerTest
//
//  Created by apple on 16/2/1.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    UITabBarController * tabBar = [[UITabBarController alloc]init];
    tabBar.tabBar.barTintColor = [UIColor greenColor];
    tabBar.tabBar.tintColor = [UIColor purpleColor];
  
    NSMutableArray * array = [[NSMutableArray alloc]init];
    for (int i=0; i<10; i++) {
        UIViewController * con = [[UIViewController alloc]init];
        con.view.backgroundColor = [UIColor colorWithRed:arc4random()%255/255.0 green:arc4random()%255/255.0 blue:arc4random()%255/255.0 alpha:1];
        con.tabBarItem = [[UITabBarItem alloc]initWithTabBarSystemItem:UITabBarSystemItemMostViewed tag:i];
        con.tabBarItem.title = [NSString stringWithFormat:@"%d视图",i];
        con.tabBarItem.image = [UIImage imageNamed:@"tab_bar_icon_home"];
        con.tabBarItem.selectedImage = [UIImage imageNamed:@"tab_bar_icon_home_selected"];
        [array addObject:con];
    }
    tabBar.viewControllers = array;
    [self presentViewController:tabBar animated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
