//
//  ViewController.m
//  UIViewControllerTest
//
//  Created by apple on 16/1/12.
//  Copyright © 2016年 apple. All rights reserved.
//
#import "ViewControllerTwo.h"
#import "ViewController.h"
int tip=0;
@interface ViewController ()

@end

@implementation ViewController
+(void)initialize{
    [super initialize];
    NSLog(@"%d initialize",++tip);
}
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    NSLog(@"%d init",++tip);
    return self;
}
- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        
    }
    NSLog(@"%d initWithCoder",++tip);
    return self;
}
-(void)awakeFromNib{
    [super awakeFromNib];
    NSLog(@"%d awakeFromNib",++tip);
}
-(void)loadView{
    [super loadView];
    NSLog(@"%d loadView",++tip);
}


- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%d viewDidLoad",++tip);
    UIView * subView = [[UIView alloc]initWithFrame:CGRectMake(20, 100, 280, 300)];
    subView.backgroundColor = [UIColor redColor];
    [self.view addSubview:subView];
    UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(20, 20, 240, 30)];
    label.backgroundColor = [UIColor blueColor];
    [subView addSubview:label];
    UIButton * button = [[UIButton alloc]initWithFrame:CGRectMake(20, 70, 240, 30)];
    button.backgroundColor = [UIColor greenColor];
    [button addTarget:self action:@selector(changeController) forControlEvents:UIControlEventTouchUpInside];
    [subView addSubview:button];
}
-(void)changeController{
    ViewControllerTwo * controller = [[ViewControllerTwo alloc]init];
    [self presentViewController:controller animated:YES completion:^{
        NSLog(@"切换完成");
    }];
}

-(void)viewWillLayoutSubviews{
    [super viewWillLayoutSubviews];
    NSLog(@"%d viewWillLayoutSubviews",++tip);
}
-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    NSLog(@"%d viewDidLayoutSubviews",++tip);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    NSLog(@"%d didReceiveMemoryWarning",++tip);
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSLog(@"%d viewWillAppear",++tip);
}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    NSLog(@"%d viewDidAppear",++tip);
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    NSLog(@"%d viewWillDisAppear",++tip);
}
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    NSLog(@"%d viewDidDisappear",++tip);
}
-(void)dealloc{
    NSLog(@"%d dealloc",++tip);
}
@end
