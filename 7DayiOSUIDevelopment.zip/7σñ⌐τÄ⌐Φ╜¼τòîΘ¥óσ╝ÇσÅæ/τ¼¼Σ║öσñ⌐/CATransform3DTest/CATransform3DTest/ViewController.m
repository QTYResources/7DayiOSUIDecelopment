//
//  ViewController.m
//  CATransform3DTest
//
//  Created by apple on 16/3/5.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImageView * image1 = [[UIImageView alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    image1.image = [UIImage imageNamed:@"image"];
    UIImageView * image2 = [[UIImageView alloc]initWithFrame:CGRectMake(100, 300, 100, 100)];
    image2.image = [UIImage imageNamed:@"image"];
    //平移
//    CATransform3D trans = CATransform3DTranslate(image2.layer.transform, 100, 100, 0);
    //缩放
//    CATransform3D tran = CATransform3DScale(trans, 0.5, 2, 0);
//    trans.m34= -1/600.0;
    CATransform3D tran = CATransform3DRotate(image2.layer.transform, M_PI_4, 0, 0, 1);
    image1.layer.transform = tran;
    image2.layer.transform = CATransform3DInvert(tran);
    [self.view addSubview:image1];
    [self.view addSubview:image2];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
