//
//  ViewController.m
//  CABasicAnimationTest
//
//  Created by apple on 16/3/3.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    CALayer * layer;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    layer = [CALayer layer];
    layer.bounds = CGRectMake(0, 0, 100, 100);
    layer.position = CGPointMake(160, 100);
    layer.backgroundColor = [UIColor redColor].CGColor;
    [self.view.layer addSublayer:layer];
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    //绕z轴旋转的动画
    CABasicAnimation * ani = [CABasicAnimation animationWithKeyPath:@"transform"];
    //从0度开始
    ani.fromValue = @0;
    //旋转到180度
    ani.toValue = [NSNumber numberWithFloat:M_PI];
    //时间2S
    ani.duration = 2;
    //设置为z轴旋转
    ani.valueFunction = [CAValueFunction functionWithName:kCAValueFunctionRotateZ];
    //执行动画
    [layer addAnimation:ani forKey:@""];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
