//
//  ViewController.m
//  UIViewTransitionTest
//
//  Created by apple on 16/3/1.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    UIView * _contentView;
    UIView * _contentView2;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _contentView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 100, 100)];
    _contentView.backgroundColor = [UIColor redColor];
    [self.view addSubview:_contentView];
    _contentView2 = [[UIView alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    _contentView2.backgroundColor = [UIColor blueColor];
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
//    [UIView transitionWithView:_contentView duration:3 options:UIViewAnimationOptionTransitionFlipFromBottom|UIViewAnimationOptionAllowAnimatedContent animations:^{
////        _contentView.backgroundColor = [UIColor blueColor];
//    } completion:nil];
//    [UIView transitionFromView:_contentView toView:_contentView2 duration:3 options:UIViewAnimationOptionTransitionFlipFromBottom|UIViewAnimationOptionAllowAnimatedContent completion:nil];
    [UIView animateWithDuration:3 delay:1 usingSpringWithDamping:1 initialSpringVelocity:20 options:UIViewAnimationOptionCurveEaseIn animations:^{
        _contentView.frame = CGRectMake(100, 100, 100, 100);
    } completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
