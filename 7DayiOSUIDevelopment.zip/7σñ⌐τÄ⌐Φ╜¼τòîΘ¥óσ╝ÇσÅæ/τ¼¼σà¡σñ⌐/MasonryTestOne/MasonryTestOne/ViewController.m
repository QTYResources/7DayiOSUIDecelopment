//
//  ViewController.m
//  MasonryTestOne
//
//  Created by apple on 16/3/13.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"
#import <Masonry/Masonry.h>
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UILabel * label = [[UILabel alloc]init];
    [self.view addSubview:label];
    UILabel * label2 = [[UILabel alloc]init];
    [self.view addSubview:label2];
//    [label mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.edges.equalTo(self.view).insets(UIEdgeInsetsMake(20, 20, 20, 20));
//    }];
//    [label mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.height.equalTo(@200);
//        make.width.equalTo(@200);
//        make.center.equalTo(self.view);
//    }];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(@100);
        make.width.equalTo(label2);
        make.right.equalTo(label2.mas_left).offset(-100);
        make.leading.equalTo(self.view.mas_leading).offset(20);
        make.centerY.equalTo(self.view);
    }];
    [label2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(@100);
        make.centerY.equalTo(label);
        make.trailing.equalTo(self.view.mas_trailing).offset(-20);
    }];
    label.backgroundColor = [UIColor redColor];
    label2.backgroundColor = [UIColor blueColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
