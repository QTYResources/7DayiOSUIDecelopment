//
//  ViewController.h
//  UIViewAutoresizingXIBTest
//
//  Created by apple on 16/3/10.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

