//
//  ViewController.m
//  AutolayoutTestFour
//
//  Created by apple on 16/3/12.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIView * view = [[UIView alloc]init];
    view.translatesAutoresizingMaskIntoConstraints = NO;
    view.backgroundColor = [UIColor redColor];
    [self.view addSubview:view];
    NSNumber * width = @20;
    NSArray * constraintArray = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-width-[view(100@1000)]" options:0 metrics:@{@"width":width} views:@{@"view":view}];
    NSArray * constraintArray2 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-100-[view(100)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(view)];
    [self.view addConstraints:constraintArray];
    [self.view addConstraints:constraintArray2];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
