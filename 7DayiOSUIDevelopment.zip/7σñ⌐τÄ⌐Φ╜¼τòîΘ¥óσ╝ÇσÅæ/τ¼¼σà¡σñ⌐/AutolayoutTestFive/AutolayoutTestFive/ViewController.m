//
//  ViewController.m
//  AutolayoutTestFive
//
//  Created by apple on 16/3/13.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITextViewDelegate>
{
    UITextView * _textView ;
    NSArray * _array1;
    NSArray * _array2;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //进行文本输入框初始化
    _textView = [[UITextView alloc]init];
    _textView.layer.borderColor = [[UIColor grayColor]CGColor];
    _textView.layer.borderWidth = 1;
    _textView.translatesAutoresizingMaskIntoConstraints = NO;
    _textView.delegate=self;
    [self.view addSubview:_textView];
    //使用VFL进行约束的创建
    _array1 = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-100-[_textView]-100-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_textView)];
    _array2 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-150-[_textView(30)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_textView)];
    //添加约束
    [self.view addConstraints:_array1];
    [self.view addConstraints:_array2];
}
//监听textView中文本的变化
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    //当文本高度大于textView的高度并且小于100时，更新约束
    if (textView.contentSize.height>textView.frame.size.height&&textView.contentSize.height<100) {
        float hight =textView.contentSize.height;
        //将以前的移除掉
        [self.view removeConstraints:_array1];
        [self.view removeConstraints:_array2];
        //创建新的约束
        _array1 = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-100-[textView]-100-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(textView)];
        _array2 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-150-[textView(hight)]" options:0 metrics:@{@"hight":[NSNumber numberWithFloat:hight]} views:NSDictionaryOfVariableBindings(textView)];
        [self.view addConstraints:_array1];
        [self.view addConstraints:_array2];
    }
    //更新约束
    [self.view updateConstraintsIfNeeded];
    [UIView animateWithDuration:1 animations:^{
        [self.view layoutIfNeeded];
    }];
    return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
