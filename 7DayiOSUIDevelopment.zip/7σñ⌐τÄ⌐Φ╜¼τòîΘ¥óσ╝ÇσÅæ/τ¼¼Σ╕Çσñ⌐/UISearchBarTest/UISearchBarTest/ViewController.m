//
//  ViewController.m
//  UISearchBarTest
//
//  Created by apple on 16/1/5.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UISearchBar * searchBar = [[UISearchBar alloc]initWithFrame:CGRectMake(20, 100, 280, 30)];
    searchBar.placeholder = @"请输入文字···";
    searchBar.showsSearchResultsButton=YES;
    searchBar.searchBarStyle = UISearchBarStyleMinimal;
    searchBar.showsScopeBar = YES;
    searchBar.scopeButtonTitles = @[@"时政",@"体育",@"娱乐"];
    searchBar.selectedScopeButtonIndex = 1;
    searchBar.delegate=self;
    [self.view addSubview:searchBar];
}
//当用户点击切换扩展栏上的模块按钮是会触发下面方法
-(void)searchBar:(UISearchBar *)searchBar selectedScopeButtonIndexDidChange:(NSInteger)selectedScope{
    
}
//当用户向SearchBar控件中输入的文字改变时会触发下面方法
-(BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    return 1;
}
//当SearchBar中文字改变时会触发下面方法
-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    
}
//当用户点击图书图标按钮时会触发下面方法
-(void)searchBarBookmarkButtonClicked:(UISearchBar *)searchBar{
    
}
//当用户点击取消图标按钮时会触发下面方法
-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    
}
//当用户点击搜索结果箭头按钮时会触发下面方法
-(void)searchBarResultsListButtonClicked:(UISearchBar *)searchBar{
    
}
//当用户点击键盘上的搜索按钮时会触发下面方法
-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    
}
//当SearchBar控件结束编辑时会触发下面方法
-(void)searchBarTextDidEndEditing:(UISearchBar *)searchBar{
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
