//
//  ViewController.m
//  UISliderTest
//
//  Created by apple on 16/1/10.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor redColor];
    UISlider * slider = [[UISlider alloc]initWithFrame:CGRectMake(20, 100, 280, 40)];
    [slider addTarget:self action:@selector(changeBG:) forControlEvents:UIControlEventValueChanged];
//    slider.minimumValue = 0;
//    slider.maximumValue = 10;
//    
    slider.minimumTrackTintColor = [UIColor blueColor];
    slider.maximumTrackTintColor = [UIColor greenColor];
    slider.thumbTintColor = [UIColor purpleColor];
    slider.minimumValueImage = [UIImage imageNamed:@"cj_mxz_xingxing"];
    slider.maximumValueImage = [UIImage imageNamed:@"cj_xz_xingxing"];
    slider.continuous = NO;
    [self.view addSubview:slider];
}

-(void)changeBG:(UISlider *)slider{
    self.view.backgroundColor = [UIColor colorWithRed:1 green:0 blue:0 alpha:1-slider.value];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
